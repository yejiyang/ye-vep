c      Inculde file name for partition data and the number of partitions
       parameter (fname1='elem0.elm\0')
       parameter (fname2='13\0')
c
c      Parameters for lmddm file
c
